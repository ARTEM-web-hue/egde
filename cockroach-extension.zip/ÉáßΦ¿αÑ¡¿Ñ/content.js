let isActive = false;

// Функция для получения URL файла из расширения
function getCockroachImageURL() {
  try {
    return chrome.runtime.getURL('cockroach.png');
  } catch (e) {
    try {
      return chrome.runtime.getURL('cockroach.gif');
    } catch (e2) {
      return null;
    }
  }
}

document.addEventListener('keydown', function(e) {
  console.log('Key pressed:', e.key, 'Ctrl:', e.ctrlKey, 'Alt:', e.altKey);
  
  // Проверяем комбинацию Ctrl + Alt + E (латинская) или У (кириллическая)
  const isEKey = e.key === 'e' || e.key === 'E' || e.key === 'у' || e.key === 'У';
  
  if (e.ctrlKey && e.altKey && isEKey) {
    e.preventDefault();
    console.log('Комбинация Ctrl+Alt+E/У сработала!');
    
    // Предотвращаем множественные срабатывания
    if (isActive) return;
    isActive = true;
    
    // Создаем тараканов
    for (let i = 0; i < 15; i++) {
      setTimeout(() => {
        createCockroach();
      }, i * 100);
    }
    
    // Отключаем через 3 секунды (но тараканы остаются до клика)
    setTimeout(() => {
      isActive = false;
    }, 3000);
  }
});

// Функция создания одного таракана
function createCockroach() {
  const cockroach = document.createElement('div');
  cockroach.style.position = 'fixed';
  cockroach.style.left = Math.random() * (window.innerWidth - 60) + 'px';
  cockroach.style.top = Math.random() * (window.innerHeight - 60) + 'px';
  cockroach.style.width = '60px';
  cockroach.style.height = '60px';
  cockroach.style.zIndex = '999999999';
  cockroach.style.pointerEvents = 'auto'; // Важно: разрешаем клики
  cockroach.style.cursor = 'pointer'; // Показываем, что можно кликать
  cockroach.style.display = 'flex';
  cockroach.style.alignItems = 'center';
  cockroach.style.justifyContent = 'center';
  cockroach.style.fontSize = '40px';
  cockroach.style.userSelect = 'none'; // Запрещаем выделение текста
  
  const imageURL = getCockroachImageURL();
  
  if (imageURL) {
    // Если есть файл изображения
    cockroach.style.backgroundImage = `url('${imageURL}')`;
    cockroach.style.backgroundSize = 'contain';
    cockroach.style.backgroundRepeat = 'no-repeat';
    cockroach.style.backgroundPosition = 'center';
  } else {
    // Если нет файла, используем эмодзи
    cockroach.textContent = '🪳';
  }
  
  document.body.appendChild(cockroach);
  
  // Добавляем обработчик клика
  cockroach.addEventListener('click', function() {
    console.log('Таракан пойман!');
    // Добавляем эффект исчезновения
    cockroach.style.transition = 'opacity 0.3s ease';
    cockroach.style.opacity = '0';
    
    // Удаляем элемент после анимации
    setTimeout(() => {
      if (cockroach.parentNode) {
        cockroach.remove();
      }
    }, 300);
  });
  
  // Движение таракана
  moveCockroach(cockroach);
  
  return cockroach;
}

// Функция движения таракана
function moveCockroach(cockroach) {
  let x = parseFloat(cockroach.style.left);
  let y = parseFloat(cockroach.style.top);
  
  const interval = setInterval(() => {
    // Случайное движение
    const deltaX = (Math.random() - 0.5) * 15;
    const deltaY = (Math.random() - 0.5) * 15;
    
    x = Math.max(0, Math.min(window.innerWidth - 60, x + deltaX));
    y = Math.max(0, Math.min(window.innerHeight - 60, y + deltaY));
    
    cockroach.style.left = x + 'px';
    cockroach.style.top = y + 'px';
    
    // Поворот в направлении движения
    if (deltaX !== 0 || deltaY !== 0) {
      const rotation = Math.atan2(deltaY, deltaX) * 180 / Math.PI;
      cockroach.style.transform = `rotate(${rotation}deg)`;
    }
    
  }, 100);
  
  // Останавливаем движение через 60 секунд (на случай, если не кликнут)
  setTimeout(() => {
    clearInterval(interval);
  }, 99999);
}